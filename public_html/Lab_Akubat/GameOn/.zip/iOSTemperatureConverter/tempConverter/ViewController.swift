//
//  ViewController.swift
//  tempConverter
//
//  Created by student on 11/10/15.
//  Copyright (c) 2015 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet weak var UserText: UITextField!//user input
    @IBOutlet weak var ConvertToWhat: UILabel!//cel||fah

    @IBOutlet weak var Switch: UISwitch!
    @IBOutlet weak var ConvertValue: UILabel!

    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //ios keyboard go away
    
    @IBAction func switchPressed(sender: AnyObject)
    {
        if (Switch.on)
        {
        
            ConvertToWhat.text = "Celsius to Fahrenheit"
        }
        else
        {
        
            ConvertToWhat.text = "Fahrenheit to Celsius"
        }
        
    }

    
    
    @IBAction func RUN(sender: AnyObject)
    {
        
        var V:Int = UserText.text.toInt()!
        
        var toCelsius:Int = V-32*5/9
        var toFahrenheit:Int =   32+V*9/5
        var celAnswer = V.description + " fahrenheit in celsius equals "
        var fahAnswer = V.description + " celsius in fahrenheit equals "

        if (Switch.on)
        {
            ConvertValue.text =  fahAnswer + toCelsius.description
        }
            
        else
        {
            
            ConvertValue.text = celAnswer + toFahrenheit.description
        }
        
    }
    

}

